SNR Gutter Pro

This updated version supports multiple photos of the same house.

Features:
- Add front, rear, left, right and detail photos
- Draw gutter measurements on each photo
- Draw downspout measurements on each photo
- Downspouts are calculated only by total footage, not by sticks
- All photo measurements combine into one estimate
- Pricing for gutter footage, downspout footage, elbows, endcaps, outlets and miters
- Separate gutter cover type, footage and price
- Labor/material deduction and added pricing
- Save job in the browser
- Save each marked photo
- Print or save the estimate as a PDF

Upload index.html to GitHub Pages to publish it.
